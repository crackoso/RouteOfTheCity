<?php

/**
 * RutaUbicaciones filter form base class.
 *
 * @package    rutatragica
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class BaseRutaUbicacionesFormFilter extends BaseFormFilterDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'ruta_id'      => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Ruta'), 'add_empty' => true)),
      'ubicacion_id' => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Ubicacion'), 'add_empty' => true)),
      'posicion'     => new sfWidgetFormFilterInput(),
    ));

    $this->setValidators(array(
      'ruta_id'      => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('Ruta'), 'column' => 'id')),
      'ubicacion_id' => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('Ubicacion'), 'column' => 'id')),
      'posicion'     => new sfValidatorPass(array('required' => false)),
    ));

    $this->widgetSchema->setNameFormat('ruta_ubicaciones_filters[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'RutaUbicaciones';
  }

  public function getFields()
  {
    return array(
      'id'           => 'Number',
      'ruta_id'      => 'ForeignKey',
      'ubicacion_id' => 'ForeignKey',
      'posicion'     => 'Text',
    );
  }
}
