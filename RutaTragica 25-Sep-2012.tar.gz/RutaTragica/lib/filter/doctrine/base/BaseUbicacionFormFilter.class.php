<?php

/**
 * Ubicacion filter form base class.
 *
 * @package    rutatragica
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class BaseUbicacionFormFilter extends BaseFormFilterDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'titulo'                => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'descripcion'           => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'url'                   => new sfWidgetFormFilterInput(),
      'idioma'                => new sfWidgetFormChoice(array('choices' => array('' => '', 'Español' => 'Español', 'Inglés' => 'Inglés'))),
      'latitud'               => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'longitud'              => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'archivo1'              => new sfWidgetFormFilterInput(),
      'archivo2'              => new sfWidgetFormFilterInput(),
      'archivo3'              => new sfWidgetFormFilterInput(),
      'archivo4'              => new sfWidgetFormFilterInput(),
      'archivo5'              => new sfWidgetFormFilterInput(),
      'ruta_ubicaciones_list' => new sfWidgetFormDoctrineChoice(array('multiple' => true, 'model' => 'Ruta')),
    ));

    $this->setValidators(array(
      'titulo'                => new sfValidatorPass(array('required' => false)),
      'descripcion'           => new sfValidatorPass(array('required' => false)),
      'url'                   => new sfValidatorPass(array('required' => false)),
      'idioma'                => new sfValidatorChoice(array('required' => false, 'choices' => array('Español' => 'Español', 'Inglés' => 'Inglés'))),
      'latitud'               => new sfValidatorPass(array('required' => false)),
      'longitud'              => new sfValidatorPass(array('required' => false)),
      'archivo1'              => new sfValidatorPass(array('required' => false)),
      'archivo2'              => new sfValidatorPass(array('required' => false)),
      'archivo3'              => new sfValidatorPass(array('required' => false)),
      'archivo4'              => new sfValidatorPass(array('required' => false)),
      'archivo5'              => new sfValidatorPass(array('required' => false)),
      'ruta_ubicaciones_list' => new sfValidatorDoctrineChoice(array('multiple' => true, 'model' => 'Ruta', 'required' => false)),
    ));

    $this->widgetSchema->setNameFormat('ubicacion_filters[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function addRutaUbicacionesListColumnQuery(Doctrine_Query $query, $field, $values)
  {
    if (!is_array($values))
    {
      $values = array($values);
    }

    if (!count($values))
    {
      return;
    }

    $query
      ->leftJoin($query->getRootAlias().'.RutaUbicaciones RutaUbicaciones')
      ->andWhereIn('RutaUbicaciones.id', $values)
    ;
  }

  public function getModelName()
  {
    return 'Ubicacion';
  }

  public function getFields()
  {
    return array(
      'id'                    => 'Number',
      'titulo'                => 'Text',
      'descripcion'           => 'Text',
      'url'                   => 'Text',
      'idioma'                => 'Enum',
      'latitud'               => 'Text',
      'longitud'              => 'Text',
      'archivo1'              => 'Text',
      'archivo2'              => 'Text',
      'archivo3'              => 'Text',
      'archivo4'              => 'Text',
      'archivo5'              => 'Text',
      'ruta_ubicaciones_list' => 'ManyKey',
    );
  }
}
