<?php

/**
 * Ruta form.
 *
 * @package    rutatragica
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class RutaForm extends BaseRutaForm
{
  public function configure()
  {

      /*
      $this->widgetSchema['ruta_ubicacion_list']  = new sfWidgetFormDoctrineChoice(array(
          'model' => 'Ubicacion',
          'method'=> 'getTitulo',
          'multiple' => true,
          'order_by' => array('titulo', 'ASC')
          
          ));
      */

  }
}
