<?php

/**
 * Ubicacion form.
 *
 * @package    rutatragica
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class UbicacionForm extends BaseUbicacionForm
{
  public function configure()
  {
      $this->setWidget('url', new sfWidgetFormInputText());
      $this->setWidget('archivo1', new sfWidgetFormInputFile());
      $this->setWidget('archivo2', new sfWidgetFormInputFile());
      $this->setWidget('archivo3', new sfWidgetFormInputFile());
      $this->setWidget('archivo4', new sfWidgetFormInputFile());
      $this->setWidget('archivo5', new sfWidgetFormInputFile());
      
     
      $this->setValidator('archivo1', new sfValidatorFile(array(
        'mime_types' => 'web_images',
        'path' => sfConfig::get('sf_upload_dir').'/ubicaciones',
        'required' => false,
      )));
      $this->setValidator('archivo2', new sfValidatorFile(array(
        'mime_types' => 'web_images',
        'path' => sfConfig::get('sf_upload_dir').'/ubicaciones',
        'required' => false,
      )));
      $this->setValidator('archivo3', new sfValidatorFile(array(
        'mime_types' => 'web_images',
        'path' => sfConfig::get('sf_upload_dir').'/ubicaciones',
        'required' => false,
      )));
      $this->setValidator('archivo4', new sfValidatorFile(array(
        'mime_types' => 'web_images',
        'path' => sfConfig::get('sf_upload_dir').'/ubicaciones',
        'required' => false,
      )));
      $this->setValidator('archivo5', new sfValidatorFile(array(
        'mime_types' => 'web_images',
        'path' => sfConfig::get('sf_upload_dir').'/ubicaciones',
        'required' => false,
      )));
  }
}
