<?php

/**
 * Ubicacion form base class.
 *
 * @method Ubicacion getObject() Returns the current form's model object
 *
 * @package    rutatragica
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BaseUbicacionForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'id'                    => new sfWidgetFormInputHidden(),
      'titulo'                => new sfWidgetFormInputText(),
      'descripcion'           => new sfWidgetFormTextarea(),
      'url'                   => new sfWidgetFormTextarea(),
      'idioma'                => new sfWidgetFormChoice(array('choices' => array('Español' => 'Español', 'Inglés' => 'Inglés'))),
      'latitud'               => new sfWidgetFormInputText(),
      'longitud'              => new sfWidgetFormInputText(),
      'archivo1'              => new sfWidgetFormInputText(),
      'archivo2'              => new sfWidgetFormInputText(),
      'archivo3'              => new sfWidgetFormInputText(),
      'archivo4'              => new sfWidgetFormInputText(),
      'archivo5'              => new sfWidgetFormInputText(),
      'ruta_ubicaciones_list' => new sfWidgetFormDoctrineChoice(array('multiple' => true, 'model' => 'Ruta')),
    ));

    $this->setValidators(array(
      'id'                    => new sfValidatorChoice(array('choices' => array($this->getObject()->get('id')), 'empty_value' => $this->getObject()->get('id'), 'required' => false)),
      'titulo'                => new sfValidatorString(array('max_length' => 255)),
      'descripcion'           => new sfValidatorString(array('max_length' => 5000)),
      'url'                   => new sfValidatorString(array('max_length' => 1000, 'required' => false)),
      'idioma'                => new sfValidatorChoice(array('choices' => array(0 => 'Español', 1 => 'Inglés'))),
      'latitud'               => new sfValidatorString(array('max_length' => 30)),
      'longitud'              => new sfValidatorString(array('max_length' => 30)),
      'archivo1'              => new sfValidatorString(array('max_length' => 200, 'required' => false)),
      'archivo2'              => new sfValidatorString(array('max_length' => 200, 'required' => false)),
      'archivo3'              => new sfValidatorString(array('max_length' => 200, 'required' => false)),
      'archivo4'              => new sfValidatorString(array('max_length' => 200, 'required' => false)),
      'archivo5'              => new sfValidatorString(array('max_length' => 200, 'required' => false)),
      'ruta_ubicaciones_list' => new sfValidatorDoctrineChoice(array('multiple' => true, 'model' => 'Ruta', 'required' => false)),
    ));

    $this->widgetSchema->setNameFormat('ubicacion[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Ubicacion';
  }

  public function updateDefaultsFromObject()
  {
    parent::updateDefaultsFromObject();

    if (isset($this->widgetSchema['ruta_ubicaciones_list']))
    {
      $this->setDefault('ruta_ubicaciones_list', $this->object->RutaUbicaciones->getPrimaryKeys());
    }

  }

  protected function doSave($con = null)
  {
    $this->saveRutaUbicacionesList($con);

    parent::doSave($con);
  }

  public function saveRutaUbicacionesList($con = null)
  {
    if (!$this->isValid())
    {
      throw $this->getErrorSchema();
    }

    if (!isset($this->widgetSchema['ruta_ubicaciones_list']))
    {
      // somebody has unset this widget
      return;
    }

    if (null === $con)
    {
      $con = $this->getConnection();
    }

    $existing = $this->object->RutaUbicaciones->getPrimaryKeys();
    $values = $this->getValue('ruta_ubicaciones_list');
    if (!is_array($values))
    {
      $values = array();
    }

    $unlink = array_diff($existing, $values);
    if (count($unlink))
    {
      $this->object->unlink('RutaUbicaciones', array_values($unlink));
    }

    $link = array_diff($values, $existing);
    if (count($link))
    {
      $this->object->link('RutaUbicaciones', array_values($link));
    }
  }

}
