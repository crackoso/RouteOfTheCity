<h1>Lista de Ubicaciones</h1>

<table>
  <thead>
    <tr>
      <!--<th>Id</th>-->
      <th>Titulo</th>
      <th>Descripci&oacute;n</th>
      <th>Idioma</th>
      <!--<th>Latitud</th>-->
      <!--<th>Longitud</th>-->
    </tr>
  </thead>
  <tbody>
    <?php foreach ($ubicacions as $ubicacion): ?>
    <tr>
      <!--<td><a href="<?php //echo url_for('ubicacion/show?id='.$ubicacion->getId()) ?>"><?php //echo $ubicacion->getId() ?></a></td>-->
      <td><a href="<?php echo url_for('ubicacion/show?id='.$ubicacion->getId()) ?>"><?php echo $ubicacion->getTitulo() ?></a></td>
      <td><a href="<?php echo url_for('ubicacion/show?id='.$ubicacion->getId()) ?>"><?php echo $ubicacion->getDescripcion() ?></a></td>
      <td><a href="<?php echo url_for('ubicacion/show?id='.$ubicacion->getId()) ?>"><?php echo $ubicacion->getIdioma() ?></a></td>
      <!--<td><a href="<?php //echo url_for('ubicacion/show?id='.$ubicacion->getId()) ?>"><?php //echo $ubicacion->getLatitud() ?></a></td>-->
      <!--<td><a href="<?php //echo url_for('ubicacion/show?id='.$ubicacion->getId()) ?>"><?php //echo $ubicacion->getLongitud() ?></a></td>-->
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

  <a href="<?php echo url_for('ubicacion/new') ?>">Nueva</a>
