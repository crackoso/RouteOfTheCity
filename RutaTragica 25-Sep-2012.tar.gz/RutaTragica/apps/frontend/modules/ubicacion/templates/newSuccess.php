<h1>Nueva Ubicaci&oacute;n</h1>

<?php include_partial('form', array('form' => $form)) ?>
