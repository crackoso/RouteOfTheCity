<h1>Editar Ubicaci&oacute;n</h1>

<?php include_partial('form', array('form' => $form)) ?>
