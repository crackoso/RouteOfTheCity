<h1>Edit Sf guard user</h1>

<?php include_partial('form', array('form' => $form)) ?>
