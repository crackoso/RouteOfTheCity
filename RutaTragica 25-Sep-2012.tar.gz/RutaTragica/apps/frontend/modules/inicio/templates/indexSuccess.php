<table>
    <tr>
        <td>
            <a href="<?php echo url_for('@homepage') ?>">Home</a>
        </td>
    </tr>
    <tr>
        <td>
            <a href="<?php echo url_for('ruta/new') ?>">Ruta</a>
        </td>
    </tr>
    <tr>
        <td>
            <a href="<?php echo url_for('ubicacion/new') ?>">Ubicaci&oacute;n</a>
        </td>
    </tr>
    <tr>
        <td>
            <a href="<?php echo url_for('rutaUbicaciones/new') ?>">Ruta-Ubicaciones </a>
        </td>
    </tr>
    <tr>
        <td>
            <a href="<?php echo url_for('@sf_guard_signout') ?>">Cerrar Sesi&oacute;n </a>
        </td>
    </tr>
</table>