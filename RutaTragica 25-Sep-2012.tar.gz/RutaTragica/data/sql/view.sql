CREATE OR REPLACE VIEW view_rutas AS
  SELECT r.nombre, u.titulo, ru.posicion, u.descripcion, u.url, u.idioma, u.latitud, u.longitud, u.archivo1, u.archivo2, u.archivo3, u.archivo4, u.archivo5
  FROM ruta r, ubicacion u, ruta_ubicaciones ru
  WHERE ru.ubicacion_id = u.id
  AND ru.ruta_id = r.id 
  ORDER BY ru.posicion, u.titulo ASC