<?php

$host="localhost";
$user="root";
$password="root";
$db="rutatragica";
$order=$_GET["order"];
$idioma=$_GET["idioma"];


$conexion = mysql_connect($host, $user, $password);
mysql_select_db($db);

$consulta=  mysql_query("SELECT * FROM view_rutas WHERE idioma = '".$idioma."' ORDER BY ".$order);

$json=array();

while($datos = mysql_fetch_assoc($consulta))
{
    $row_array['nombre'] = htmlentities($datos['nombre']);
    $row_array['titulo'] = htmlentities($datos['titulo']);
    $row_array['descripcion'] = htmlentities($datos['descripcion']);
    $row_array['posicion'] = htmlentities($datos['posicion']);
    $row_array['url'] = htmlentities($datos['url']);
    $row_array['idioma'] = htmlentities($datos['idioma']);
    $row_array['latitud'] = htmlentities($datos['latitud']);
    $row_array['longitud'] = htmlentities($datos['longitud']);
    $row_array['archivo1'] = $datos['archivo1'];
    $row_array['archivo2'] = $datos['archivo2'];
    $row_array['archivo3'] = $datos['archivo3'];
    $row_array['archivo4'] = $datos['archivo4'];
    $row_array['archivo5'] = $datos['archivo5'];
    
    array_push($json, $row_array);
}
//echo "SELECT * FROM view_rutas WHERE idioma = '".$idioma."' ORDER BY ".$order;



echo json_encode($json);

mysql_close($conexion);
?>
