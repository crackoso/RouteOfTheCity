<td>
  <input type="checkbox" name="ids[]" value="<?php echo $sf_guard_user->getPrimaryKey() ?>" class="sf_admin_batch_checkbox" />
</td>
